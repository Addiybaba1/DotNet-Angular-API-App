﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectApis.Migrations
{
    /// <inheritdoc />
    public partial class FinalLog1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("835806d6-af83-4e6e-871f-0a35e407513f"));

            migrationBuilder.AlterColumn<string>(
                name: "Password",
                table: "Users",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("221ad3e9-84d0-4942-b861-7df540226a3c"), null, null, null, new DateTime(2024, 10, 8, 8, 13, 56, 938, DateTimeKind.Utc).AddTicks(8900), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$LzbCnDF7YGpuhxxJU7FUI.JNCMZ3.ns9sHdVekuKM8P/8Afyhemr2", null, null, null, "superadmin", null, new DateTime(2024, 10, 8, 8, 13, 56, 938, DateTimeKind.Utc).AddTicks(8901), "superadmin" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("221ad3e9-84d0-4942-b861-7df540226a3c"));

            migrationBuilder.AlterColumn<string>(
                name: "Password",
                table: "Users",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("835806d6-af83-4e6e-871f-0a35e407513f"), null, null, null, new DateTime(2024, 10, 8, 8, 3, 15, 234, DateTimeKind.Utc).AddTicks(5361), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$/q6HH6tHYPvOUWaY1fU2A.rAunxBgbSDaSLCEX5T3PqjRLfLDPxXe", null, null, null, "superadmin", null, new DateTime(2024, 10, 8, 8, 3, 15, 234, DateTimeKind.Utc).AddTicks(5361), "superadmin" });
        }
    }
}
