﻿    using System.ComponentModel.DataAnnotations;
    using System.Text.RegularExpressions;

    namespace ProjectApis.Validator
    {
        public class PasswordValidator : ValidationAttribute
        {
            protected override ValidationResult IsValid(object? value, ValidationContext validationContext)
            {
                if (value == null || string.IsNullOrEmpty(value.ToString()))
                {
                    return new ValidationResult("Password is required.");
                }
                var password = value as string;
                var hasNumber = new Regex(@"[0-9]+");
                var hasUpperChar = new Regex(@"[A-Z]+");
                var hasLowerChar = new Regex(@"[a-z]+");
                var hasMiniMaxChars = new Regex(@".{8,}");
                var hasSpecialChar = new Regex(@"[\W]+");

                if (!hasMiniMaxChars.IsMatch(password))
                {
                    return new ValidationResult("Password must be at least 8 characters long.");
                }
                else if (!hasUpperChar.IsMatch(password))
                {
                    return new ValidationResult("Password must contain at least one uppercase letter.");
                }
                else if (!hasLowerChar.IsMatch(password))
                {
                    return new ValidationResult("Password must contain at least one lowercase letter.");
                }
                else if (!hasNumber.IsMatch(password))
                {
                    return new ValidationResult("Password must contain at least one numeric digit.");
                }
                else if (!hasSpecialChar.IsMatch(password))
                {
                    return new ValidationResult("Password must contain at least one special character.");
                }

                return ValidationResult.Success;
            }
        }
    }
