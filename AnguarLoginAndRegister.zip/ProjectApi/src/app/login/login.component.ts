import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterOutlet, ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  title = 'ProjectApi';
  loginForm: FormGroup;
  successMessage: string | null = null;
  errorMessage: string | null = null;

  constructor(private http: HttpClient, private fb: FormBuilder, private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });

    const isLoggedIn = !!localStorage.getItem('username');
    const userRole = localStorage.getItem('role');
    if (isLoggedIn) {
      if (userRole === 'superadmin') {
        this.router.navigate(['/adminpage']);
      } else if (userRole === 'user') {
        this.router.navigate(['/userpage']);
      }
    }
  }

  onLogin() {
    this.successMessage = null;
    this.errorMessage = null;

    if (this.loginForm.invalid) {
      return;
    }

    const formData = new FormData();
    formData.append('Username', this.loginForm.get('username')?.value || '');
    formData.append('Password', this.loginForm.get('password')?.value || '');

    this.http.post('https://localhost:7050/api/User/login', formData).subscribe({
      next: (response: any) => {
        console.log('Successful Response:', response);
        this.successMessage = 'Login successful!';
        localStorage.setItem('username', response.username);
        localStorage.setItem('role', response.role);

        console.log('Stored Username:', localStorage.getItem('username'));
        console.log('Stored Role:', localStorage.getItem('role'));

        if (response.role === 'superadmin') {
          this.router.navigate(['/adminpage']);
        } else if (response.role === 'user') {
          this.router.navigate(['/userpage']);
        }
      },
      error: (error: HttpErrorResponse) => {
        if (error.status === 401) {
          this.errorMessage = error.error.message || 'Invalid username or password.';
        } else {
          this.errorMessage = 'An unexpected error occurred. Please try again later.';
        }
        console.log('Error:', this.errorMessage);
      }
    });
  }
}
