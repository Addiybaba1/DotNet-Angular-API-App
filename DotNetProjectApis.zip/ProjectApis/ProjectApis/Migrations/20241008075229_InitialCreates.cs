﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectApis.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreates : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("57c5350e-2be2-4b3e-b644-b81f57cee0bd"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("e257ccf3-5d7e-4592-815d-c64d5e1e0726"), null, null, null, new DateTime(2024, 10, 8, 7, 52, 28, 19, DateTimeKind.Utc).AddTicks(86), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$RbkzRHr8V8z6nzc/Nxwf6urT5JcfXc5VnBgVntn9tZGCFrboSF/5i", null, null, null, "superadmin", null, new DateTime(2024, 10, 8, 7, 52, 28, 19, DateTimeKind.Utc).AddTicks(86), "superadmin" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("e257ccf3-5d7e-4592-815d-c64d5e1e0726"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("57c5350e-2be2-4b3e-b644-b81f57cee0bd"), null, null, null, new DateTime(2024, 10, 7, 20, 9, 28, 606, DateTimeKind.Utc).AddTicks(9259), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$uMeztSrJgpI//nHLt4iPzucALa/V2xIteQ5.HQIcym7eT/FM72f5W", null, null, null, "superadmin", null, new DateTime(2024, 10, 7, 20, 9, 28, 606, DateTimeKind.Utc).AddTicks(9260), "superadmin" });
        }
    }
}
