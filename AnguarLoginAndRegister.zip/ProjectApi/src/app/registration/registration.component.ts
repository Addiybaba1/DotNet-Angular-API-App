import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [RouterOutlet, ReactiveFormsModule, CommonModule],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent {

  title = 'User Registration'; 
  
  registrationForm: FormGroup;
  successMessage: string | null = null;
  errors: any = {};

  constructor(private http: HttpClient, private fb: FormBuilder) {
    this.registrationForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[\W])/)]],
    });
  }

  onSubmit() {  
    this.successMessage = null;
    this.errors = {};

    if (this.registrationForm.invalid) {
      return; 
    }

    const formData = new FormData();
    formData.append('Username', this.registrationForm.get('username')?.value || '');
    formData.append('Email', this.registrationForm.get('email')?.value || '');
    formData.append('Password', this.registrationForm.get('password')?.value || '');

    this.http.post('https://localhost:7050/api/User/register', formData).subscribe({
      next: (response) => {
        console.log('Successful Response:', response);
        this.successMessage = 'Registration successful!';
        this.registrationForm.reset();
      },
      error: (error: HttpErrorResponse) => {
        if (error.status === 400 && error.error.errors) {
          this.errors = error.error.errors;
          console.log('Validation errors:', this.errors);
        } else if (error.error.message) {
          console.log('General error message:', error.error.message);
          if (error.error.message.includes('Email')) {
            this.errors.Email = [error.error.message];
          }
          if (error.error.message.includes('Username')) {
            this.errors.Username = [error.error.message];
          }
        }
      }
    });
  }
}
