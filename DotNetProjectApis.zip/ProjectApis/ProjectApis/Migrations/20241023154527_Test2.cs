﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectApis.Migrations
{
    /// <inheritdoc />
    public partial class Test2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("221ad3e9-84d0-4942-b861-7df540226a3c"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("6075eec6-7b19-489a-81ed-9297e6a9ab33"), null, null, null, new DateTime(2024, 10, 23, 15, 45, 25, 460, DateTimeKind.Utc).AddTicks(5922), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$zVNENB0ADVHZzEqhFvllwuFhsKcsWO/ntzybF57iyV/6V1ci6DfLK", null, null, null, "superadmin", null, new DateTime(2024, 10, 23, 15, 45, 25, 460, DateTimeKind.Utc).AddTicks(5923), "superadmin" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("6075eec6-7b19-489a-81ed-9297e6a9ab33"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("221ad3e9-84d0-4942-b861-7df540226a3c"), null, null, null, new DateTime(2024, 10, 8, 8, 13, 56, 938, DateTimeKind.Utc).AddTicks(8900), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$LzbCnDF7YGpuhxxJU7FUI.JNCMZ3.ns9sHdVekuKM8P/8Afyhemr2", null, null, null, "superadmin", null, new DateTime(2024, 10, 8, 8, 13, 56, 938, DateTimeKind.Utc).AddTicks(8901), "superadmin" });
        }
    }
}
