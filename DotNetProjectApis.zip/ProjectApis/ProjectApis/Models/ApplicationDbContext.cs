﻿using Microsoft.EntityFrameworkCore;

namespace ProjectApis.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Employeecs> employeecs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            var adminPassword = BCrypt.Net.BCrypt.HashPassword("SuperAdmin123!");
            modelBuilder.Entity<User>().HasData(new User
            {
                Id = Guid.NewGuid(),
                Username = "superadmin",
                Email = "superadmin@domain.com",
                Password = adminPassword,
                FirstName = "Super",
                LastName = "Admin",
                Role = "superadmin",
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
        }
    }
}
