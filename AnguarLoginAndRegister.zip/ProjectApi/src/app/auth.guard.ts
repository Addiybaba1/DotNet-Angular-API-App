import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const isLoggedIn = localStorage.getItem('username');
    const userRole = localStorage.getItem('role');
    const currentUrl = state.url;

    // console.log('Current URL:', currentUrl);

    if (!isLoggedIn) {
      this.router.navigate(['/login']);
      return false;
    }

    if (userRole === 'superadmin' && currentUrl === '/userpage') {
      this.router.navigate(['/access-denied']);
      return false;
    }

    if (userRole === 'user' && currentUrl === '/adminpage') {
      this.router.navigate(['/access-denied']);
      return false;
    }

    if (isLoggedIn && currentUrl === '/register') {
      this.router.navigate(['/home']);
      return false;
    }

    return true;
  }
}
