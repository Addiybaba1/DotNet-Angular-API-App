﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectApis.Migrations
{
    /// <inheritdoc />
    public partial class FinalLog : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("e257ccf3-5d7e-4592-815d-c64d5e1e0726"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("835806d6-af83-4e6e-871f-0a35e407513f"), null, null, null, new DateTime(2024, 10, 8, 8, 3, 15, 234, DateTimeKind.Utc).AddTicks(5361), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$/q6HH6tHYPvOUWaY1fU2A.rAunxBgbSDaSLCEX5T3PqjRLfLDPxXe", null, null, null, "superadmin", null, new DateTime(2024, 10, 8, 8, 3, 15, 234, DateTimeKind.Utc).AddTicks(5361), "superadmin" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("835806d6-af83-4e6e-871f-0a35e407513f"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("e257ccf3-5d7e-4592-815d-c64d5e1e0726"), null, null, null, new DateTime(2024, 10, 8, 7, 52, 28, 19, DateTimeKind.Utc).AddTicks(86), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$RbkzRHr8V8z6nzc/Nxwf6urT5JcfXc5VnBgVntn9tZGCFrboSF/5i", null, null, null, "superadmin", null, new DateTime(2024, 10, 8, 7, 52, 28, 19, DateTimeKind.Utc).AddTicks(86), "superadmin" });
        }
    }
}
