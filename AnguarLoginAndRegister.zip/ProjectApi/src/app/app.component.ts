import { Component, AfterViewInit  } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import $ from 'jquery';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ProjectApi'; 

  ngAfterViewInit() {
    setTimeout(() => {
      ($('.navbar-toggler') as any).collapse();
    }, 0);
  }

  constructor(private router: Router) {}

  isLoggedIn(): boolean {
    return !!localStorage.getItem('username');
  }

  isAdmin(): boolean {
    return localStorage.getItem('role') === 'superadmin';
  }

  isuser(): boolean {
    return localStorage.getItem('role') === 'user';
  }

  logout(): void {
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    this.router.navigate(['/login']);
  }


}
