﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjectApis.Models;

namespace ProjectApis.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeecsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public EmployeecsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Employeecs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employeecs>>> Getemployeecs()
        {
            return await _context.employeecs.ToListAsync();
        }

        // GET: api/Employeecs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Employeecs>> GetEmployeecs(Guid id)
        {
            var employeecs = await _context.employeecs.FindAsync(id);

            if (employeecs == null)
            {
                return NotFound();
            }

            return employeecs;
        }

        // PUT: api/Employeecs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployeecs(Guid id, Employeecs employeecs)
        {
            if (id != employeecs.EmpId)
            {
                return BadRequest();
            }

            _context.Entry(employeecs).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeecsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Employeecs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Employeecs>> PostEmployeecs(Employeecs employeecs)
        {
            _context.employeecs.Add(employeecs);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEmployeecs", new { id = employeecs.EmpId }, employeecs);
        }

        // DELETE: api/Employeecs/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployeecs(Guid id)
        {
            var employeecs = await _context.employeecs.FindAsync(id);
            if (employeecs == null)
            {
                return NotFound();
            }

            _context.employeecs.Remove(employeecs);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmployeecsExists(Guid id)
        {
            return _context.employeecs.Any(e => e.EmpId == id);
        }
    }
}
