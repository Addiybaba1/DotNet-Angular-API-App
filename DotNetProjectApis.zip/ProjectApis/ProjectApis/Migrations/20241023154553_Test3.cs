﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectApis.Migrations
{
    /// <inheritdoc />
    public partial class Test3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("6075eec6-7b19-489a-81ed-9297e6a9ab33"));

            migrationBuilder.CreateTable(
                name: "employeecs",
                columns: table => new
                {
                    EmpId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_employeecs", x => x.EmpId);
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("314d141b-62df-4259-8d59-41e16549d483"), null, null, null, new DateTime(2024, 10, 23, 15, 45, 52, 629, DateTimeKind.Utc).AddTicks(3776), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$dcExTBXa1Vh6S84zHiG0VOels.55dNV.q4CpBYznFpSwpCvmrSWfa", null, null, null, "superadmin", null, new DateTime(2024, 10, 23, 15, 45, 52, 629, DateTimeKind.Utc).AddTicks(3777), "superadmin" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "employeecs");

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("314d141b-62df-4259-8d59-41e16549d483"));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Address", "City", "Country", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "Password", "PhoneNumber", "PostalCode", "ProfilePicture", "Role", "State", "UpdatedAt", "Username" },
                values: new object[] { new Guid("6075eec6-7b19-489a-81ed-9297e6a9ab33"), null, null, null, new DateTime(2024, 10, 23, 15, 45, 25, 460, DateTimeKind.Utc).AddTicks(5922), "superadmin@domain.com", "Super", true, "Admin", "$2a$11$zVNENB0ADVHZzEqhFvllwuFhsKcsWO/ntzybF57iyV/6V1ci6DfLK", null, null, null, "superadmin", null, new DateTime(2024, 10, 23, 15, 45, 25, 460, DateTimeKind.Utc).AddTicks(5923), "superadmin" });
        }
    }
}
